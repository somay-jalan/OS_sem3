#include <stdio.h>
#include <stdint.h>
#include<math.h>

int main() {
    printf("STARTED\n");
    // Count from 1 to 2^32
    for (unsigned long long i = 1; i <(pow(2,32)); i++) {
    // Do nothing
    }
    printf("ENDED\n");
    return 0;
}
